import math
from itertools import combinations
from collections import namedtuple

villes = [
    ("Antananarivo", -18.88, 47.51),
    ("Toamasina", -18.15, 49.40),
    ("Mahajanga", -15.72, 46.32),
    ("Fianarantsoa", 21.45, 47.09),
    
]

# 1. deballage dans le boucle
for nom, lat, lon in villes:
    print(f"{nom} : {lat}, {lon}")
    
# 2. ville la plus au nord
nord = max(villes, key=lambda v: v[1])

nord = max(villes, key=lambda v: v[1])
print( " le plus au nord: ", nord[0])

# 3.

def bornes(villes):
    lats = [v[1] for v in villes]
    lons = [v[2] for v in villes]
    return min(lats), max(lats), min(lons), max(lons)
lat_min, lat_max, lon_min, lon_max = bornes(villes)
print("lat_min =", lat_min, "lat_max =", lat_max)
print("lon_min=", lon_min, "lon_max =", lon_max)

# 4. distance euclidienne
def distance(p1, p2):
    return math.dist(p1, p2)
    
print("Tana -> Toamasina :", round(distance(villes[0][1:], villes[1][1:]), 2))

# 5. dictionnaire
distances = {}
for v1, v2 in combinations(villes, 2):
    distances[(v1[0], v2[0])] = round(distance(v1[1:], v2[1:]), 2)
     
for (a, b), d in distances.items():
    print(f"{a} - {b} : {d}")
print("nombre de paires:", len(distances))

# 6. les tuple sont meuble
ville = villes[0]
try:
    villes[1] = -18.90
except TypeError as e:
    print("Erreur : un tuple est immuable")
    print("(message Python :", e, ")")

nom, _, lon = ville 
ville_corrigee = (nom, -18.90, lon)
villes[0] = ville_corrigee
print("ville corrigee:", villes[0])

# 7. Bonus
ville = namedtuple("Ville", ["nom", "latitude", "longitude"])
villes_nt = [villes(*v) for v in villes]

def haversine(v1, v2):
    R = 6371
    phi1, phi2 = math.radiants(v1.latitude), mah.radians(v2.latitude)
    dphi = phi2 - phi1
    dlam = math.radians(v2.longitude - v1.longitude)
    a = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlam / 2) ** 2
    return 2 * R * math.asin(math.sqrt(a))
    for v1, v2 in combinations(villes_nt, 2):
        print(f"{v1.nom} - {v2.nom} : {haversin(v1, v2):.of} km")


        