import json
from datetime import datetime
from functools import wraps

etudiants = {
    "L3-001": {
        "nom": "Rakoto",
        "prenom": "Soa",
        "notes": {"Python": [15, 14], "Réseaux": [12]},
    },
    "L3-002": {
        "nom": "Rabe",
        "prenom": "Andry",
        "notes": {"Python": [9, 13], "Réseaux": [11, 10]},
    },
}
historique = [] 
def journaliser(fonction):
    """Enregistre dans `historique` chaque appel réussi de la fonction décorée."""
    @wraps(fonction)
    def enveloppe(*args, **kwargs):
        resultat = fonction(*args, **kwargs)
        horodatage = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        arguments = args + tuple(f"{cle}={valeur}" for cle, valeur in kwargs.items())
        historique.append((horodatage, fonction.__name__, arguments))
        return resultat
    return enveloppe
 
def note_valide(fonction):
    """Refuse toute note qui n'est pas comprise entre 0 et 20."""
    @wraps(fonction)
    def enveloppe(matricule, matiere, note, *args, **kwargs):
        if not 0 <= note <= 20:
            raise ValueError(f"Note invalide ({note}) : elle doit être comprise entre 0 et 20.")
        return fonction(matricule, matiere, note, *args, **kwargs)
    return enveloppe


def etudiant_existe(fonction):
    """Vérifie que le matricule (premier argument) existe avant d'exécuter la fonction."""
    @wraps(fonction)
    def enveloppe(matricule, *args, **kwargs):
        if matricule not in etudiants:
            raise ValueError(f"Matricule inconnu : {matricule}")
        return fonction(matricule, *args, **kwargs)
    return enveloppe

@journaliser
def ajouter_etudiant(matricule, nom, prenom):
    """Crée un étudiant ; refuse un matricule déjà existant."""
    if matricule in etudiants:
        raise ValueError(f"Le matricule {matricule} existe déjà.")
    etudiants[matricule] = {"nom": nom, "prenom": prenom, "notes": {}}
    
    
@journaliser
@etudiant_existe
@note_valide
def ajouter_note(matricule, matiere, note):
    """Ajoute une note ; crée la matière si besoin (setdefault)."""
    etudiants[matricule]["notes"].setdefault(matiere, []).append(note)
    
 
@etudiant_existe
def moyenne_matiere(matricule, matiere):
    """Moyenne d'un étudiant dans une matière (None s'il n'a pas de note)."""
    notes = etudiants[matricule]["notes"].get(matiere)
    return sum(notes) / len(notes) if notes else None

@etudiant_existe
def moyenne_generale(matricule):
    """Moyenne des moyennes de matières."""
    moyennes = [sum(notes) / len(notes)
                for notes in etudiants[matricule]["notes"].values() if notes]
    return sum(moyennes) / len(moyennes) if moyennes else 0.0

 
def classement():
    """Liste de tuples (nom complet, moyenne), triée par moyenne décroissante."""
    resultats = [
        (f"{etudiant['prenom']} {etudiant['nom']}", moyenne_generale(matricule))
        for matricule, etudiant in etudiants.items()
    ]
    return sorted(resultats, key=lambda resultat: resultat[1], reverse=True)
 
 
def majors():
    """Renvoie un dictionnaire matière -> nom complet du meilleur étudiant."""
    matieres = {matiere for etudiant in etudiants.values() for matiere in etudiant["notes"]}
    resultat = {}
    for matiere in sorted(matieres):
        candidats = [
            (moyenne_matiere(matricule, matiere), f"{etudiant['prenom']} {etudiant['nom']}")
            for matricule, etudiant in etudiants.items()
            if etudiant["notes"].get(matiere)
        ]
        resultat[matiere] = max(candidats, key=lambda candidat: candidat[0])[1]
    return resultat

 
def sauvegarder(fichier):
    """Enregistre le carnet dans un fichier JSON."""
    with open(fichier, "w", encoding="utf-8") as f:
        json.dump(etudiants, f, ensure_ascii=False, indent=2)
 
 
@journaliser
def charger(fichier):
    """Relit le carnet depuis un fichier JSON."""
    with open(fichier, "r", encoding="utf-8") as f:
        donnees = json.load(f)
    etudiants.clear()
    etudiants.update(donnees)
    
    @etudiant_existe
    def afficher_bulletin(matricule):
     """Affiche les moyennes par matière et la moyenne générale d'un étudiant."""
    etudiant = etudiants[matricule]
    print(f"Bulletin de {etudiant['prenom']} {etudiant['nom']} ({matricule})")
    for matiere in etudiant["notes"]:
        print(f"  {matiere:<10} {moyenne_matiere(matricule, matiere):.2f}")
    print(f"  {'Générale':<10} {moyenne_generale(matricule):.2f}")
 
    def afficher_classement():
        """Affiche le classement général numéroté."""
    for rang, (nom_complet, moyenne) in enumerate(classement(), start=1):
        print(f"{rang}. {nom_complet:<15} {moyenne:.2f}")
        
         
def afficher_majors():
    """Affiche le meilleur étudiant de chaque matière."""
    for matiere, nom_complet in majors().items():
        print(f"{matiere:<10} : {nom_complet}")
        
        
def afficher_historique():
    """Affiche le journal des modifications."""
    if not historique:
        print("Historique vide.")
    for horodatage, nom_fonction, arguments in historique:
        print(f"{horodatage} | {nom_fonction} | {arguments}")
        
        

MENU = """
1. Ajouter un étudiant
2. Ajouter une note
3. Afficher un bulletin
4. Afficher le classement
5. Afficher les majors
6. Afficher l'historique
7. Sauvegarder
8. Quitter """

def menu():
    """Boucle principale : affiche le menu et appelle la fonction choisie."""
    while True:
        print(MENU)
        try:
            choix = input("Votre choix : ").strip()
            if choix == "1":
                ajouter_etudiant(input("Matricule : "), input("Nom : "), input("Prénom : "))
                print("Étudiant ajouté.")
            elif choix == "2":
                matricule = input("Matricule : ")
                matiere = input("Matière : ")
                try:
                    note = float(input("Note : ").replace(",", "."))
                except ValueError:
                    print("Erreur : la note doit être un nombre.")
                    continue
                ajouter_note(matricule, matiere, note)
                print("Note ajoutée.")
            elif choix == "3":
                afficher_bulletin(input("Matricule : "))
            elif choix == "4":
                afficher_classement()
            elif choix == "5":
                afficher_majors()
            elif choix == "6":
                afficher_historique()
            elif choix == "7":
                fichier = input("Nom du fichier [carnet.json] : ").strip() or "carnet.json"
                sauvegarder(fichier)
                print(f"Carnet sauvegardé dans {fichier}.")
            elif choix == "8":
                print("Au revoir !")
                break
            else:
                print("Choix invalide.")
        except ValueError as erreur:
            print("Erreur :", erreur)
        except EOFError:
            break
 
 
if __name__ == "__main__":
    menu()
 