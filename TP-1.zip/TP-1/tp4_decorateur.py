import time
from functools import cache, wraps, lru_cache

#1
def chronometrer (fonction):
    @wraps(fonction)
    def enveloppe(*args, **kwargs):
        debut = time.perf_counter()
        resultat = fonction(*args, **kwargs)
        duree = time.perf_counter() - debut 
        print(f"{fonction.__name__} a pris {duree:.2f} s")
        return resultat
    return enveloppe

@chronometrer
def lente():
    """fonction volontairement lente"""
    time.sleep(1)
    lente()
    print("nom conserve grace a @wraps :", lente.__name__)
    
#2. @majuscules
    def majuscules(fonction):
        @wraps(fonction)
        def enveloppe(*args, **kwargs):
             resultat = fonction(*args, **kwargs).upper()
             return resultat.upper()
        return enveloppe

def majuscules (fonction):
    @wraps(fonction)
    def enveloppe(*args, **kwargs):
        def enveloppe(*args, **kwargs):
            resultat = fonction(*args, **kwargs)
            return resultat.upper()
            return enveloppe
        
@majuscules
def saluer():
    return "bonjour"

print(saluer()) 

# 3. @compter_appels
def compter_appels(func):
    @wraps(func)
    def enveloppe(*args, **kwargs):
        enveloppe.appels += 1
        return func(*args, **kwargs)
    enveloppe.appels = 0
    return enveloppe

@compter_appels
def fonction():
    return "ok"
fonction(); fonction(); fonction()
print("fonction.appels =", fonction.appels)

def verifier_positifs(func):
    @wraps(func)
    def enveloppe(*args, **kwargs):
        for valeur in list(args) + list(kwargs.values()):
            if isinstance(valeur, (int, float)) and valeur < 0:
                raise ValueError(f"Argument negatif refuse : {valeur}")
        return func(*args, **kwargs)
    return enveloppe

@verifier_positifs
def surface(longueur, largeur):
    return longueur * largeur

# 4. 
print("surface(4, 5) =", surface(4, 5))
try:
    surface(4, -5)
except ValueError as e:
    print("Erreur :", e)
    
#5.
def chronometrer_param(unite="s"):
    if unite not in ("s", "ms"):
            raise ValueError("unite doit valoir 's' ou 'ms'")
 
    def decorateur(fonction):
        @wraps(fonction)
        def enveloppe(*args, **kwargs):
            debut = time.perf_counter()
            resultat = fonction(*args, **kwargs)
            duree = time.perf_counter() - debut
            if unite == "ms":
                print(f"{fonction.__name__} a pris {duree * 1000:.2f} ms")
            else:
                print(f"{fonction.__name__} a pris {duree:.2f} s")
            return resultat
        return enveloppe
    return decorateur
    
 
    @chronometrer_param(unite="ms")
    def courte():
        time.sleep(0.05)
    courte()
    
# 6.
def memoriser(fonction):
        cache = {}
 
    @wraps(fonction)
def enveloppe(*args):
        if args not in cache:         
            cache[args] = fonction(*args)
        return cache[args]
        return enveloppe

def fibonacci(n):
    if n < 2:
        return n
    return fibonacci(n - 1) + fibonacci(n - 2)
@memoriser
def fibonacci_memo(n):
    if n < 2:
        return n
    return fibonacci_memo(n - 1) + fibonacci_memo(n - 2)
 
 
@lru_cache(maxsize=None)
def fibonacci_lru(n):
    if n < 2:
        return n
    return fibonacci_lru(n - 1) + fibonacci_lru(n - 2)
 
print("sans cache      :", chronometrer(fibonacci)(30))
print("avec @memoriser :", chronometrer(fibonacci_memo)(30))
print("avec lru_cache  :", chronometrer(fibonacci_lru)(30))

# 7.
@chronometrer
@compter_appels
def f1():
    pass
 
@compter_appels
@chronometrer
def f2():
    pass


for _ in range(3):
    f1()
    f2()
    
print("f1 (chronometrer au-dessus) : f1.appels =", f1.appels,
      "| vrai compteur =", f1.__wrapped__.appels)
print("f2 (compter_appels au-dessus) : f2.appels =", f2.appels)

# 8. 
class MiniFlask:
    def __init__(self):
        self.routes = {}
        self.gestionnaire_404 = lambda url: f"404 - page introuvable : {url}"
 
    def route(self, url):
        def decorateur(fonction):
            if url in self.routes:
                raise ValueError(f"URL déjà enregistrée : {url}")
            self.routes[url] = fonction
            return fonction
        return decorateur
    
    def erreur_404(self, fonction):
        """Décorateur : définit la fonction appelée pour une URL inconnue."""
        self.gestionnaire_404 = fonction
        return fonction
 
    def lister_routes(self):
        for url, fonction in self.routes.items():
            print(f"{url} -> {fonction.__name__}")
 
    def repondre(self, url):
        fonction = self.routes.get(url)
        return fonction() if fonction else self.gestionnaire_404(url)
    app = MiniFlask()
 
 
@app.route("/")
def accueil():
    return "Bienvenue"
 
 
@app.route("/contact")
def contact():
    return "Contactez-nous"
 
 
@app.erreur_404
def introuvable(url):
    return f"Oups, {url} n'existe pas."
 
 
app.lister_routes()
print(app.repondre("/"))
print(app.repondre("/inconnue"))
 
try:
    @app.route("/contact")
    def contact_bis():
        return "doublon"
except ValueError as e:
    print("Erreur :", e)
 


