notes = [12, 8, 15, 17, 9, 11, 14, 6, 13, 16]

#1. statistiques de base

moyenne = round(sum(notes) / len(notes), 2)
print("nombre de notes:", len(notes))
print(f"moyenne : {moyenne:,2f}")
print("Min :", min(notes))
print("Max :", max(notes))

# 2. notes >= 10
admis = [n for n in notes if n >= 10]
ajournes = len(notes) - len(admis)
print(admis)
print(ajournes, "ajournés")

# 3. tri sans modifier

croissant = sorted(notes)          
print(croissant)
print(croissant[-3:][::-1])  

# 4. rattrapage
apres_deliberation = [min(n + 2, 10) if n < 10 else n for n in notes]
print(apres_deliberation)

# 5. histogramme
def histogramme(notes):
    """Affiche une étoile par note, regroupées par tranche."""
    tranches = [("0-4", 0, 4), ("5-9", 5, 9), ("10-14", 10, 14), ("15-20", 15, 20)]
    for nom, bas, haut in tranches:
        nb = len([n for n in notes if bas <= n <= haut])
        print(f"{nom:<5} | {'*' * nb}".rstrip())

histogramme(notes)

# 6. rang dans le classement
def rang(notes, note):
    """Renvoie la position de `note` dans le classement décroissant (1 = meilleure)."""
    classement = sorted(notes, reverse=True)
    return classement.index(note) + 1 
print("rang(notes, 14) =", rang(notes, 14))


# 7. Bonus
fusion = list(dict.fromkeys(notes + [15, 6, 18]))
print(fusion)
