import json
from collections import Counter
stock = {
    "riz": {"prix": 3200, "quantite": 50},
    "huille" : {"prix": 9500, "quantite": 12},
    "sucre" : {"prix": 4000, "quantite":30},
    "savon" : {"prix": 1500, "quantite": 0},
    
}

# 1.
for produit, info in stock.items():
    print(f"{produit:<6} {info['prix']:>5} Ar  | quantité : {info['quantite']}")
    
# 2.
total = sum(info["prix"] * info["quantite"] for info in stock.values())
print(f"Valeur totale : {total:,} Ar".replace(",", " "))

#3. 
rupture = [produit for produit, info in stock.items() if info["quantite"] == 0]
print(rupture)

# 4.
def vendre(stock, produit, quantite):
    """Vend `quantite` unités de `produit`. Renvoie (succes, message)."""
    info = stock.get(produit)          
    if info is None:
        return (False, f"Produit inconnu : {produit}")
    if quantite <= 0:
        return (False, "La quantité doit être positive.")
    if quantite > info["quantite"]:
        return (False, f"Stock insuffisant pour {produit} "
                       f"(demandé : {quantite}, disponible : {info['quantite']})")
    info["quantite"] -= quantite
    return (True, f"Vente de {quantite} {produit} : {quantite * info['prix']} Ar")

# 5.
def ajouter_produit(stock, nom, prix, quantite):
    """Ajoute un produit. Refuse un produit déjà présent."""
    if nom in stock:
        return (False, f"{nom} existe dans le stock.")
    stock[nom] = {"prix": prix, "quantite": quantite}
    return (True, f"{nom} ajoute")

# 6.
prix_hausse = {p: round(info["prix"] * 1.10) for p, info in stock.items()}
print(prix_hausse)

#7.
ventes = ["riz", "sucre", "riz", "huile", "riz"]
 
compte = {}
for produit in ventes:
    compte[produit] = compte.get(produit, 0) + 1   
print("Avec get     :", compte)
 
compteur = Counter(ventes)
print("Avec Counter :", dict(compteur))

# 8.
with open("stock.json", "w", encoding="utf-8") as f:
    json.dump(stock, f, ensure_ascii=False, indent=2)
 
with open("stock.json", "r", encoding="utf-8") as f:
    stock_recharge = json.load(f)
 
print("Dictionnaires égaux :", stock == stock_recharge)